# 🌿 HimShakti ProductWriter AI

> **Project:** AI-02 | Food Processing Product Description Generator  
> **Intern ID:** TBI-26100266 | **TBI-GEU Internship**  
> **Week 4 Status:** ✅ Backend & API Development Complete

---

## 🚀 One-Line Pitch
AI-powered tool generating keyword-optimized, tone-customized Amazon product descriptions for HimShakti's Himalayan food range.

---

## 📡 REST API — 8 Endpoints

| # | Method | Endpoint | Status | Description |
|---|--------|----------|--------|-------------|
| 1 | `GET`    | `/api/health`                  | 200 | Health check + AI status |
| 2 | `GET`    | `/api/descriptions`            | 200 | List all (filter + pagination) |
| 3 | `GET`    | `/api/descriptions/stats`      | 200 | Counts by tone, avg words |
| 4 | `GET`    | `/api/descriptions/search?q=`  | 200 | Search by name/ingredients |
| 5 | `GET`    | `/api/descriptions/{id}`       | 200 | Get single by ID |
| 6 | `POST`   | `/api/generate`                | 201 | AI generate + auto-save |
| 7 | `PUT`    | `/api/descriptions/{id}`       | 200 | Update text or tone |
| 8 | `DELETE` | `/api/descriptions/{id}`       | 204 | Delete — No Content |

---

## 🛠️ Tech Stack

```
Frontend   →  React 18 + Vite 5 + Tailwind CSS v3
Backend    →  FastAPI (Python 3.11) + Uvicorn
AI Engine  →  Google Gemini 1.5 Flash
Data Store →  In-memory (Week 4) → MongoDB Atlas (Week 5)
Auth       →  JWT (Week 5)
Deploy     →  Vercel (FE) + Render (BE)
```

---

## ▶️ How to Run Backend Locally

### Prerequisites
- Python 3.11+
- A Google Gemini API key ([get one free here](https://aistudio.google.com/app/apikey))

### Steps

```bash
# 1. Navigate to the backend folder
cd server

# 2. Create a virtual environment
python -m venv venv

# 3. Activate it
# Windows:
venv\Scripts\activate
# macOS/Linux:
source venv/bin/activate

# 4. Install dependencies
pip install -r requirements.txt

# 5. Set up environment variables
cp .env.example .env
# Then open .env and add your GEMINI_API_KEY

# 6. Run the server
uvicorn main:app --reload --port 8000

# API is now live at:  http://localhost:8000
# Swagger docs at:     http://localhost:8000/api/docs
# ReDoc at:            http://localhost:8000/api/redoc
```

### Quick API Test (curl)
```bash
# Health check
curl http://localhost:8000/api/health

# List descriptions
curl http://localhost:8000/api/descriptions

# Generate a description
curl -X POST http://localhost:8000/api/generate \
  -H "Content-Type: application/json" \
  -d '{"productName":"Himalayan Turmeric","tone":"health-focused","weight":"100g"}'

# Search
curl "http://localhost:8000/api/descriptions/search?q=turmeric"
```

---

## ▶️ How to Run Frontend Locally

```bash
cd client
npm install
npm run dev   # → http://localhost:5173
```

> The frontend proxies `/api/*` to `http://localhost:8000` via Vite's proxy config.

---

## 📁 Project Structure

```
himshakti-productwriter-ai/
├── client/                          # React 18 + Vite + Tailwind
│   └── src/
│       ├── components/              # Navbar, ToneSelector, Toast, Skeleton...
│       ├── pages/                   # Home, Generate, History
│       ├── hooks/useGenerate.js     # API state management
│       └── utils/design-tokens.js  # Design system
├── server/                          # FastAPI backend
│   ├── main.py                      # 8 REST endpoints
│   ├── requirements.txt
│   └── .env.example
├── project-brief/
│   ├── W4_FrontendBackendConnection_TBI-26100266.pdf
│   └── W4_APICollection_TBI-26100266.json
└── README.md
```

---

## 📦 Week Progress

| Week | Deliverable | Status |
|------|------------|--------|
| 1 | Project Brief + Architecture | ✅ |
| 2 | React Frontend (Tailwind) | ✅ |
| 3 | UI/UX & Component Design | ✅ |
| 4 | Backend & API (FastAPI, 8 endpoints) | ✅ |
| 5 | Database (MongoDB) + Auth (JWT) | 🔜 |
| 6 | Deployment + Final Demo | 🔜 |

---

*TBI-GEU Internship · AI-02 · TBI-26100266*
