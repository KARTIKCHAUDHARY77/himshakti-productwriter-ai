"""
HimShakti ProductWriter AI — FastAPI Backend
Week 4: Backend & API Development
Intern ID: TBI-26100266

Endpoints (8 total):
  GET    /api/health
  GET    /api/descriptions
  GET    /api/descriptions/stats
  GET    /api/descriptions/search
  GET    /api/descriptions/{id}
  POST   /api/generate
  PUT    /api/descriptions/{id}
  DELETE /api/descriptions/{id}
"""

from fastapi import FastAPI, HTTPException, Query, status
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime
import uuid
import os
from dotenv import load_dotenv

# ── Optional Gemini integration ─────────────────────────────────────────────
try:
    import google.generativeai as genai
    load_dotenv()
    GEMINI_KEY = os.getenv("GEMINI_API_KEY", "")
    if GEMINI_KEY:
        genai.configure(api_key=GEMINI_KEY)
        gemini_model = genai.GenerativeModel("gemini-1.5-flash")
        AI_ENABLED = True
    else:
        AI_ENABLED = False
except ImportError:
    AI_ENABLED = False

# ── App setup ───────────────────────────────────────────────────────────────
app = FastAPI(
    title="HimShakti ProductWriter AI",
    description="REST API for AI-powered e-commerce product description generation",
    version="1.0.0",
    docs_url="/api/docs",
    redoc_url="/api/redoc",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://localhost:3000",
        "https://himshakti-productwriter.vercel.app",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── In-memory data store (Week 4 — DB comes in Week 5) ─────────────────────
descriptions_store: List[dict] = [
    {
        "id": "d1a2b3c4",
        "productName": "Pure Himalayan Turmeric Powder",
        "keyIngredients": "Turmeric, Black Pepper, Natural Curcumin",
        "weight": "100g",
        "brand": "HimShakti — Uttarakhand",
        "features": "Organic certified, Cold-ground, 3.5% curcumin, Lab-tested",
        "tone": "health-focused",
        "description": (
            "Unlock the ancient healing power of the Himalayas with HimShakti Pure Turmeric Powder. "
            "Sourced from high-altitude organic farms in Uttarakhand, our turmeric boasts a verified "
            "curcumin content of over 3.5%. Cold-ground to preserve volatile oils and bioactive "
            "compounds. No artificial colour, no fillers — just pure mountain gold, lab-tested for "
            "purity. Ideal for golden milk, curries, and daily wellness routines."
        ),
        "wordCount": 72,
        "createdAt": "2026-06-10T08:00:00Z",
        "updatedAt": "2026-06-10T08:00:00Z",
    },
    {
        "id": "e5f6g7h8",
        "productName": "Organic Pahadi Ghee",
        "keyIngredients": "A2 Pahadi Cow Milk, Desi Butter",
        "weight": "500ml",
        "brand": "HimShakti — Uttarakhand",
        "features": "Bilona method, Grass-fed cows, No preservatives, Single-origin",
        "tone": "premium",
        "description": (
            "Crafted from the milk of free-grazing Pahadi cows nourished on wild Himalayan herbs, "
            "HimShakti Organic Pahadi Ghee is the epitome of artisanal dairy excellence. "
            "Slow-churned using the traditional bilona method — a 48-hour process that separates "
            "butter by hand — this ghee retains a rich, nutty aroma and a naturally golden hue. "
            "No preservatives, no blending — pure mountain luxury in every jar."
        ),
        "wordCount": 68,
        "createdAt": "2026-06-11T09:30:00Z",
        "updatedAt": "2026-06-11T09:30:00Z",
    },
    {
        "id": "i9j0k1l2",
        "productName": "Wild Forest Honey",
        "keyIngredients": "Raw Wildflower Honey, Rhododendron Nectar",
        "weight": "250g",
        "brand": "HimShakti — Shivalik Hills",
        "features": "Raw unfiltered, No heating, Indigenous harvesting, Single-forest",
        "tone": "traditional",
        "description": (
            "HimShakti Wild Forest Honey is gathered by indigenous beekeepers from pristine forest "
            "reserves nestled in the Shivalik hills. Following age-old harvesting practices passed "
            "down through generations, this raw, unfiltered honey carries the essence of wildflowers "
            "and rhododendron blossoms unique to the region. No heating, no pasteurisation — "
            "nature delivers it perfect. A jar of tradition, a gift of nature."
        ),
        "wordCount": 70,
        "createdAt": "2026-06-12T10:00:00Z",
        "updatedAt": "2026-06-12T10:00:00Z",
    },
]

# ── Pydantic models ──────────────────────────────────────────────────────────
VALID_TONES = {"health-focused", "premium", "traditional"}

class GenerateRequest(BaseModel):
    productName:    str   = Field(..., min_length=2, max_length=200)
    keyIngredients: str   = Field(default="", max_length=500)
    weight:         str   = Field(default="", max_length=50)
    brand:          str   = Field(default="HimShakti", max_length=100)
    features:       str   = Field(default="", max_length=500)
    tone:           str   = Field(default="health-focused")

    class Config:
        json_schema_extra = {
            "example": {
                "productName": "Pure Himalayan Turmeric Powder",
                "keyIngredients": "Turmeric, Black Pepper",
                "weight": "100g",
                "brand": "HimShakti",
                "features": "Organic, Cold-ground, Lab-tested",
                "tone": "health-focused",
            }
        }

class UpdateRequest(BaseModel):
    description: Optional[str] = Field(None, min_length=10)
    tone:        Optional[str] = None

class DescriptionOut(BaseModel):
    id:             str
    productName:    str
    keyIngredients: str
    weight:         str
    brand:          str
    features:       str
    tone:           str
    description:    str
    wordCount:      int
    createdAt:      str
    updatedAt:      str

# ── Helper ───────────────────────────────────────────────────────────────────
def make_fallback(req: GenerateRequest) -> str:
    """Return a template description when Gemini is unavailable."""
    tone_phrases = {
        "health-focused": f"a nutritious, wellness-focused food product",
        "premium":        f"a premium, artisanal specialty",
        "traditional":    f"a traditional, heritage food product",
    }
    return (
        f"Introducing {req.productName} by {req.brand or 'HimShakti'} — "
        f"{tone_phrases.get(req.tone, 'a quality food product')}. "
        f"{'Made with ' + req.keyIngredients + '. ' if req.keyIngredients else ''}"
        f"{'Available in ' + req.weight + '. ' if req.weight else ''}"
        f"{'Key features: ' + req.features + '.' if req.features else ''} "
        f"Sourced from the pristine Himalayan region, this product brings quality and "
        f"purity to your table. No artificial additives — just nature's best."
    )

TONE_PROMPTS = {
    "health-focused": "Use evidence-backed, benefit-led language. Emphasise nutrients, wellness, certifications.",
    "premium":        "Use sophisticated, aspirational language. Emphasise exclusivity and artisanal craft.",
    "traditional":    "Use warm, nostalgic language. Emphasise heritage, age-old recipes, authenticity.",
}

# ════════════════════════════════════════════════════════════════════════════
# ENDPOINT 1 — Health check
# ════════════════════════════════════════════════════════════════════════════
@app.get("/api/health", tags=["System"], status_code=200)
def health_check():
    """Check API health and service status."""
    return {
        "status": "ok",
        "service": "HimShakti ProductWriter AI",
        "version": "1.0.0",
        "ai_enabled": AI_ENABLED,
        "total_descriptions": len(descriptions_store),
        "timestamp": datetime.utcnow().isoformat() + "Z",
    }

# ════════════════════════════════════════════════════════════════════════════
# ENDPOINT 2 — List all descriptions (with optional tone filter)
# ════════════════════════════════════════════════════════════════════════════
@app.get("/api/descriptions", tags=["Descriptions"], status_code=200)
def list_descriptions(
    tone: Optional[str] = Query(None, description="Filter by tone: health-focused | premium | traditional"),
    limit: int          = Query(20, ge=1, le=100),
    skip:  int          = Query(0,  ge=0),
):
    """Return all saved descriptions, optionally filtered by tone."""
    result = descriptions_store
    if tone:
        if tone not in VALID_TONES:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Invalid tone '{tone}'. Must be one of: {', '.join(VALID_TONES)}",
            )
        result = [d for d in result if d["tone"] == tone]
    paginated = result[skip: skip + limit]
    return {
        "total": len(result),
        "skip": skip,
        "limit": limit,
        "data": paginated,
    }

# ════════════════════════════════════════════════════════════════════════════
# ENDPOINT 3 — Stats (counts by tone)
# ════════════════════════════════════════════════════════════════════════════
@app.get("/api/descriptions/stats", tags=["Descriptions"], status_code=200)
def get_stats():
    """Return aggregated statistics across all saved descriptions."""
    by_tone = {"health-focused": 0, "premium": 0, "traditional": 0}
    total_words = 0
    for d in descriptions_store:
        tone = d.get("tone", "")
        if tone in by_tone:
            by_tone[tone] += 1
        total_words += d.get("wordCount", 0)
    avg_words = round(total_words / len(descriptions_store), 1) if descriptions_store else 0
    return {
        "totalDescriptions": len(descriptions_store),
        "byTone": by_tone,
        "averageWordCount": avg_words,
        "totalWords": total_words,
    }

# ════════════════════════════════════════════════════════════════════════════
# ENDPOINT 4 — Search by product name
# ════════════════════════════════════════════════════════════════════════════
@app.get("/api/descriptions/search", tags=["Descriptions"], status_code=200)
def search_descriptions(q: str = Query(..., min_length=1, description="Search query")):
    """Search saved descriptions by product name (case-insensitive)."""
    q_lower = q.strip().lower()
    results = [
        d for d in descriptions_store
        if q_lower in d["productName"].lower()
        or q_lower in d.get("keyIngredients", "").lower()
    ]
    return {"query": q, "total": len(results), "data": results}

# ════════════════════════════════════════════════════════════════════════════
# ENDPOINT 5 — Get single description by ID
# ════════════════════════════════════════════════════════════════════════════
@app.get("/api/descriptions/{description_id}", tags=["Descriptions"], status_code=200)
def get_description(description_id: str):
    """Fetch a single description by its ID."""
    item = next((d for d in descriptions_store if d["id"] == description_id), None)
    if not item:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Description with id '{description_id}' not found.",
        )
    return item

# ════════════════════════════════════════════════════════════════════════════
# ENDPOINT 6 — Generate (AI) + auto-save
# ════════════════════════════════════════════════════════════════════════════
@app.post("/api/generate", tags=["AI Generation"], status_code=201)
async def generate_description(req: GenerateRequest):
    """Generate an AI-powered product description and save it."""
    if req.tone not in VALID_TONES:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid tone. Must be one of: {', '.join(VALID_TONES)}",
        )

    # Try Gemini, fall back to template
    if AI_ENABLED:
        try:
            prompt = (
                f"You are an expert Amazon copywriter for HimShakti, a premium Himalayan food brand.\n"
                f"Write a compelling, keyword-rich product description (150–200 words) for:\n"
                f"Product: {req.productName}\n"
                f"Ingredients: {req.keyIngredients or 'Not specified'}\n"
                f"Weight: {req.weight or 'Not specified'}\n"
                f"Features: {req.features or 'Not specified'}\n"
                f"Tone instruction: {TONE_PROMPTS.get(req.tone, '')}\n"
                f"Rules: Flowing prose only. No bullet points. No markdown. "
                f"Start with a hook. End with a CTA."
            )
            response   = gemini_model.generate_content(prompt)
            text       = response.text.strip()
        except Exception as e:
            text = make_fallback(req)
    else:
        text = make_fallback(req)

    now  = datetime.utcnow().isoformat() + "Z"
    item = {
        "id":             str(uuid.uuid4())[:8],
        "productName":    req.productName,
        "keyIngredients": req.keyIngredients,
        "weight":         req.weight,
        "brand":          req.brand,
        "features":       req.features,
        "tone":           req.tone,
        "description":    text,
        "wordCount":      len(text.split()),
        "createdAt":      now,
        "updatedAt":      now,
    }
    descriptions_store.append(item)
    return {"message": "Description generated and saved.", "data": item}

# ════════════════════════════════════════════════════════════════════════════
# ENDPOINT 7 — Update description text or tone
# ════════════════════════════════════════════════════════════════════════════
@app.put("/api/descriptions/{description_id}", tags=["Descriptions"], status_code=200)
def update_description(description_id: str, body: UpdateRequest):
    """Edit the text or tone of a saved description."""
    item = next((d for d in descriptions_store if d["id"] == description_id), None)
    if not item:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Description '{description_id}' not found.",
        )
    if body.tone and body.tone not in VALID_TONES:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid tone '{body.tone}'.",
        )
    if body.description:
        item["description"] = body.description
        item["wordCount"]   = len(body.description.split())
    if body.tone:
        item["tone"] = body.tone
    item["updatedAt"] = datetime.utcnow().isoformat() + "Z"
    return {"message": "Description updated.", "data": item}

# ════════════════════════════════════════════════════════════════════════════
# ENDPOINT 8 — Delete description
# ════════════════════════════════════════════════════════════════════════════
@app.delete("/api/descriptions/{description_id}", tags=["Descriptions"], status_code=204)
def delete_description(description_id: str):
    """Permanently delete a saved description."""
    global descriptions_store
    original_len = len(descriptions_store)
    descriptions_store = [d for d in descriptions_store if d["id"] != description_id]
    if len(descriptions_store) == original_len:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Description '{description_id}' not found.",
        )
    return  # 204 No Content

# ── Global error handlers ────────────────────────────────────────────────────
from fastapi import Request
from fastapi.responses import JSONResponse

@app.exception_handler(404)
async def not_found_handler(request: Request, exc):
    return JSONResponse(status_code=404, content={"error": "Resource not found", "path": str(request.url)})

@app.exception_handler(500)
async def server_error_handler(request: Request, exc):
    return JSONResponse(status_code=500, content={"error": "Internal server error"})
